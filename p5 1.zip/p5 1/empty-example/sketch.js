function setup() {
  // put setup code here
  createCanvas(400, 400);
background(220);
}

function draw() {
  // put drawing code here
  fill(150);
  strokeWeight(1);
stroke(51);
ellipse(44, 126, 60, 60);
fill(50);
  strokeWeight(1);
stroke(51);
ellipse(200, 122, 80, 80);
 strokeWeight(1);
 fill(300);
stroke(150);
ellipseMode(RADIUS);
fill(255);
ellipse(140, 300, 140, 140); // Outer white ellipse
ellipseMode(CENTER);
fill(1);
ellipse(80, 270, 60, 60);
strokeWeight(4);
 fill(210);
stroke(150);
ellipse(320, 287, 90, 90);

strokeWeight(4);
fill(1);
rect(0, 0, 133, 50);

strokeWeight(4);
fill(1);
rect(133, 0, 133, 50);

strokeWeight(4);
fill(1);
rect(266, 0, 133, 50);

strokeWeight(4);
fill(1);
rect(0, 350, 133, 50);

strokeWeight(4);
fill(1);
rect(133, 350, 133, 50);

strokeWeight(4);
fill(1);
rect(266, 350, 133, 50);

line(133, 0, 133, 350);
line(0, 0, 0, 350);
line(266, 0, 266, 350);
line(400, 0, 400, 350);

strokeWeight(10);
point(85, 220);
point(300, 75);
strokeWeight(5);
point(390, 187);
strokeWeight(7);
point(284, 211);
strokeWeight(3);
point(156, 173);
point(99, 77);

}