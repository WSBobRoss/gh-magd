let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;
var col = { 
    r: 0, 
    g: 0,
    b: 0,
}


function setup() {
  
  createCanvas(800, 800);
  background(255);

    col.r= random(0,255);
    col.g= random(0,255);
    col.b= random(0,255);
 
  let fr=60;
  frameRate(fr);
}

function draw() {

  let fr=75;
  frameRate(fr);

  let mx = mouseX;
  let my = mouseY;
  let px = pmouseX;
  let py = pmouseY;

  strokeWeight(6);
  
    col.r= random(0,255);
    col.g= random(0,255);
    col.b= random(0,255);

    stroke(col.r,col.g,col.b);

  line(mx, my, px, py);

}