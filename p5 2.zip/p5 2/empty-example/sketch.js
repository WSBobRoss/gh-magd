function setup() {
  createCanvas(500, 400);
  
  background(100);
  
}
function draw() {
  colorMode(RGB, 255, 255, 255, 1);
  
  fill(255,0,0);
  stroke(255,0,0);
  strokeWeight(3);
  circle(100,100,60);
  stroke(255,255,255);
  
  line(70,100,80,150);
  line(130,100,120,150);
  fill(92,51,51);
  stroke(92,51,51);
  rect(80,150,40,40);
  
  
  fill(0,255,0);
  stroke(0,255,0);
  strokeWeight(3);
  circle(250,200,100);
  
  stroke(255,255,255);
  line(200,200,220,300);
  line(300,200,270,300);
  fill(92,51,51);
  stroke(92,51,51);
  rect(220,300,50,50);
  
    fill(0,100,255);
  stroke(0,100,255);
  strokeWeight(3);
  circle(400,120,80);

 stroke(255,255,255);
  line(360,120,380,190);
  line(440,120,420,190);
  fill(92,51,51);
  stroke(92,51,51);
  rect(380,190,40,40);

}